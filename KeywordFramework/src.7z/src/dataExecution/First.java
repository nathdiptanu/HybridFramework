package dataExecution;

import java.applet.Applet;
import java.awt.Graphics;




	public class First extends Applet{  
		  
	    @Override
		public void paint(Graphics g){g.drawString("Welcome to India",50, 50);}  
	}
